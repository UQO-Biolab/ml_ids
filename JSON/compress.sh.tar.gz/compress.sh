#!/bin/bash

# Compression de chaque fichier dans le répertoire courant dans une archive .tar.gz
for file in *; do
    if [ -f "$file" ]; then
        tar -czf "${file}.tar.gz" "$file"
    fi
done

echo "Compression terminée."

